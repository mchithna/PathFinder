# Screen Dimensions 
WIDTH = 1200
HEIGHT = 650
MAZE_WIDTH = 800  
MAZE_HEIGHT = 600
SIDEBAR_WIDTH = 400

# Main Colours - as (R, G, B)
WHITE = (205, 214, 244)
BLACK = (17, 17, 27)
GREY = (30, 30, 46)
GRID_COLOUR = (49, 50, 68)        

# Cell Colours
START_COLOUR = (166, 218, 149)
END_COLOUR = (237, 135, 150)
VISITED_COLOUR = (69, 71, 90)

# Solver Colors
SCAN_COLOUR = (137, 220, 235)
PATH_COLOUR = (249, 226, 175)

# UI Colours
SIDEBAR_COLOUR = (24, 24, 37)
BOTTOM_BAR_COLOUR = (24, 24, 37)  
BUTTON1_COLOUR = (49, 50, 68)    
BUTTON1H_COLOUR = (69, 71, 90)   
ACTIVE_BUTTON_COLOUR = (137, 180, 250)
BUTTON_SHADOW = (17, 17, 27)    
TEXT_COLOUR = (205, 214, 244)   
ACTIVE_TEXT_COLOUR = (24, 24, 37)

# Action button Colours
ACTION_PRIMARY = (166, 218, 149) 
ACTION_HOVER = (186, 238, 169)

# Status Badge Colors
STATUS_IDLE = (69, 71, 90)       # grey
STATUS_GEN = (250, 179, 135)     # orange
STATUS_SOLVING = (137, 180, 250) # blue
STATUS_SOLVED = (166, 218, 149)  # green

# Game settings
FPS = 60
